"""
Gesture-to-cursor/keyboard action controller for Gustee.

Supported action types
----------------------
cursor_move     - Open palm controls mouse position (index fingertip tracks)
left_click      - Pinch thumb+index  (distance < threshold)
right_click     - Pinch thumb+middle (distance < threshold)
double_click    - Quick double pinch thumb+index
scroll_up       - Two fingers (index+middle) pointing up, hand moves up
scroll_down     - Two fingers (index+middle) pointing up, hand moves down
drag            - Closed fist held = mouse down; release fist = mouse up
volume_up       - Thumb pointing up, hand moves up
volume_down     - Thumb pointing up, hand moves down
mute            - Fist then open palm quickly
media_play_pause- Thumb + pinky spread (shaka)
media_next      - Swipe right (index pointing right)
media_prev      - Swipe left  (index pointing left)
screenshot      - Peace sign held 1s
zoom_in         - Pinch open (thumb+index spread)
zoom_out        - Pinch close (thumb+index together)

All actions are rate-limited with a per-action cooldown to prevent jitter.
"""

import sys
import time
import threading
import logging
from typing import Optional

log = logging.getLogger(__name__)

# ── Optional imports ───────────────────────────────────────────────────────────
try:
    import pyautogui
    pyautogui.FAILSAFE = False   # don't crash if mouse hits corner
    pyautogui.PAUSE = 0          # no built-in delay — we manage timing ourselves
    _HAS_PYAUTOGUI = True
except ImportError:
    _HAS_PYAUTOGUI = False
    log.warning("pyautogui not installed — cursor/keyboard control disabled.")

try:
    import pyautogui as _pag
    _SCREEN_W, _SCREEN_H = _pag.size() if _HAS_PYAUTOGUI else (1920, 1080)
except Exception:
    _SCREEN_W, _SCREEN_H = 1920, 1080

# ── Volume control (Windows only) ────────────────────────────────────────────
_vol_interface = None
if sys.platform == "win32":
    try:
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        from ctypes import cast, POINTER
        from comtypes import CLSCTX_ALL
        _speaker = AudioUtilities.GetSpeakers()
        # New pycaw (20260927+): AudioDevice has .EndpointVolume directly
        if hasattr(_speaker, "EndpointVolume"):
            _vol_interface = _speaker.EndpointVolume
        else:
            # Legacy pycaw: use COM Activate
            interface = _speaker.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            _vol_interface = cast(interface, POINTER(IAudioEndpointVolume))
        log.info("Volume control ready via pycaw.")
    except Exception as e:
        log.warning("pycaw not available — volume control disabled: %s", e)


# ── Landmark indices (MediaPipe hand) ────────────────────────────────────────
WRIST        = 0
THUMB_TIP    = 4
INDEX_TIP    = 8
MIDDLE_TIP   = 12
RING_TIP     = 16
PINKY_TIP    = 20
INDEX_MCP    = 5
MIDDLE_MCP   = 9
RING_MCP     = 13
PINKY_MCP    = 17
INDEX_PIP    = 6
MIDDLE_PIP   = 10
RING_PIP     = 14
PINKY_PIP    = 18
THUMB_MCP    = 2
INDEX_DIP    = 7


def _dist(a, b) -> float:
    """Euclidean distance between two (x,y,z) landmark dicts or lists."""
    return ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5


def _landmark_list(landmarks) -> list[tuple[float, float, float]]:
    """Convert MediaPipe landmarks object to plain list of (x, y, z) tuples."""
    return [(lm.x, lm.y, lm.z) for lm in landmarks]


# ── State ─────────────────────────────────────────────────────────────────────

class ControlState:
    def __init__(self):
        self.dragging        = False
        self.last_action: dict[str, float] = {}   # action_type -> last_fired timestamp
        self.prev_y: Optional[float]  = None       # for scroll/volume delta
        self.smooth_x: Optional[float] = None
        self.smooth_y: Optional[float] = None
        self.lock = threading.Lock()

    def cooldown_ok(self, action: str, seconds: float) -> bool:
        now = time.monotonic()
        with self.lock:
            if now - self.last_action.get(action, 0) >= seconds:
                self.last_action[action] = now
                return True
        return False

    def reset(self):
        with self.lock:
            if self.dragging:
                try:
                    pyautogui.mouseUp()
                except Exception:
                    pass
            self.dragging = False
            self.prev_y   = None
            self.smooth_x = None
            self.smooth_y = None
            self.last_action.clear()


_state = ControlState()


# ── Per-action handlers ───────────────────────────────────────────────────────

def _is_finger_up(pts, tip, pip) -> bool:
    """True if a finger tip is above its PIP joint (finger extended)."""
    return pts[tip][1] < pts[pip][1]


def _fingers_up(pts) -> list[bool]:
    """
    Return [thumb, index, middle, ring, pinky] — True = finger extended.

    Assumes a RIGHT hand on a front-facing (mirrored) camera.
    On a mirrored image the right-hand thumb extends to the LEFT (lower X).
    Left-hand users: thumb detection will be inverted; other fingers still work.
    """
    thumb  = pts[THUMB_TIP][0] < pts[THUMB_MCP][0]   # tip is left of MCP on mirrored right hand
    index  = _is_finger_up(pts, INDEX_TIP,  INDEX_PIP)
    middle = _is_finger_up(pts, MIDDLE_TIP, MIDDLE_PIP)
    ring   = _is_finger_up(pts, RING_TIP,   RING_PIP)
    pinky  = _is_finger_up(pts, PINKY_TIP,  PINKY_PIP)
    return [thumb, index, middle, ring, pinky]


def handle_cursor_move(pts: list) -> str:
    """Move mouse based on index fingertip position with exponential smoothing."""
    if not _HAS_PYAUTOGUI:
        return "cursor_move"
    tip = pts[INDEX_TIP]
    # Map normalised 0-1 coords to screen, with a margin so edges are reachable
    margin = 0.1
    tx = (tip[0] - margin) / (1 - 2 * margin)
    ty = (tip[1] - margin) / (1 - 2 * margin)
    tx = max(0.0, min(1.0, tx))
    ty = max(0.0, min(1.0, ty))
    screen_x = int(tx * _SCREEN_W)
    screen_y = int(ty * _SCREEN_H)

    # Exponential smoothing (alpha=0.4 → snappy but not jittery)
    alpha = 0.4
    sx = _state.smooth_x
    sy = _state.smooth_y
    if sx is None:
        sx, sy = float(screen_x), float(screen_y)
    sx = alpha * screen_x + (1 - alpha) * sx
    sy = alpha * screen_y + (1 - alpha) * sy
    _state.smooth_x, _state.smooth_y = sx, sy

    try:
        pyautogui.moveTo(int(sx), int(sy), duration=0)
    except Exception:
        pass
    return "cursor_move"


def handle_left_click(pts: list) -> str:
    if not _HAS_PYAUTOGUI:
        return "left_click"
    if _state.cooldown_ok("left_click", 0.6):
        try:
            pyautogui.click()
        except Exception:
            pass
    return "left_click"


def handle_right_click(pts: list) -> str:
    if not _HAS_PYAUTOGUI:
        return "right_click"
    if _state.cooldown_ok("right_click", 0.8):
        try:
            pyautogui.rightClick()
        except Exception:
            pass
    return "right_click"


def handle_double_click(pts: list) -> str:
    if not _HAS_PYAUTOGUI:
        return "double_click"
    if _state.cooldown_ok("double_click", 0.8):
        try:
            pyautogui.doubleClick()
        except Exception:
            pass
    return "double_click"


def handle_scroll(pts: list, direction: str) -> str:
    if not _HAS_PYAUTOGUI:
        return f"scroll_{direction}"
    if _state.cooldown_ok(f"scroll_{direction}", 0.15):
        try:
            pyautogui.scroll(5 if direction == "up" else -5)
        except Exception:
            pass
    return f"scroll_{direction}"


def handle_drag(pts: list) -> str:
    """Fist = mouse down (drag start); releasing fist stops drag."""
    if not _HAS_PYAUTOGUI:
        return "drag"
    if not _state.dragging:
        if _state.cooldown_ok("drag_start", 0.5):
            try:
                pyautogui.mouseDown()
                _state.dragging = True
            except Exception:
                pass
    return "drag"


def release_drag() -> None:
    """Call when fist gesture ends to release mouse button."""
    if _HAS_PYAUTOGUI and _state.dragging:
        try:
            pyautogui.mouseUp()
        except Exception:
            pass
        _state.dragging = False


def handle_volume(pts: list, direction: str) -> str:
    if not _state.cooldown_ok(f"volume_{direction}", 0.3):
        return f"volume_{direction}"
    if _vol_interface is not None:
        try:
            current = _vol_interface.GetMasterVolumeLevelScalar()
            delta   = 0.05 if direction == "up" else -0.05
            _vol_interface.SetMasterVolumeLevelScalar(
                max(0.0, min(1.0, current + delta)), None
            )
        except Exception:
            pass
    elif _HAS_PYAUTOGUI:
        try:
            key = "volumeup" if direction == "up" else "volumedown"
            pyautogui.press(key)
        except Exception:
            pass
    return f"volume_{direction}"


def handle_mute(pts: list) -> str:
    if not _state.cooldown_ok("mute", 1.0):
        return "mute"
    if _vol_interface is not None:
        try:
            current = _vol_interface.GetMute()
            _vol_interface.SetMute(not current, None)
        except Exception:
            pass
    elif _HAS_PYAUTOGUI:
        try:
            pyautogui.press("volumemute")
        except Exception:
            pass
    return "mute"


def handle_media(pts: list, action: str) -> str:
    if not _HAS_PYAUTOGUI:
        return action
    key_map = {
        "media_play_pause": "playpause",
        "media_next":       "nexttrack",
        "media_prev":       "prevtrack",
    }
    key = key_map.get(action)
    if key and _state.cooldown_ok(action, 1.0):
        try:
            pyautogui.press(key)
        except Exception:
            pass
    return action


def handle_screenshot(pts: list) -> str:
    if not _HAS_PYAUTOGUI:
        return "screenshot"
    if _state.cooldown_ok("screenshot", 2.0):
        try:
            pyautogui.hotkey("win", "shift", "s")
        except Exception:
            pass
    return "screenshot"


def handle_zoom(pts: list, direction: str) -> str:
    if not _HAS_PYAUTOGUI:
        return f"zoom_{direction}"
    if _state.cooldown_ok(f"zoom_{direction}", 0.5):
        try:
            if direction == "in":
                pyautogui.hotkey("ctrl", "+")
            else:
                pyautogui.hotkey("ctrl", "-")
        except Exception:
            pass
    return f"zoom_{direction}"


# ── Gesture detector ──────────────────────────────────────────────────────────

# Pinch distance threshold (normalised coords)
PINCH_THRESH   = 0.06
# How many fingers must be up for "open palm" cursor mode
OPEN_PALM_MIN  = 4


def detect_and_execute(action_type: str, landmarks) -> bool:
    """
    Given an action_type string and raw MediaPipe hand landmarks,
    detect the matching gesture and execute the action.
    Returns True if the action was taken this frame.
    """
    if not _HAS_PYAUTOGUI:
        return False

    pts = _landmark_list(landmarks)
    fingers = _fingers_up(pts)
    # fingers: [thumb, index, middle, ring, pinky]
    n_up = sum(fingers)

    if action_type == "cursor_move":
        # Open palm (4+ fingers up) — track index fingertip
        if n_up >= OPEN_PALM_MIN:
            handle_cursor_move(pts)
            return True

    elif action_type == "left_click":
        # Thumb + index pinch, others relaxed
        d = _dist(pts[THUMB_TIP], pts[INDEX_TIP])
        if d < PINCH_THRESH:
            handle_left_click(pts)
            return True

    elif action_type == "right_click":
        # Thumb + middle pinch
        d = _dist(pts[THUMB_TIP], pts[MIDDLE_TIP])
        if d < PINCH_THRESH:
            handle_right_click(pts)
            return True

    elif action_type == "double_click":
        # Thumb + index very close
        d = _dist(pts[THUMB_TIP], pts[INDEX_TIP])
        if d < PINCH_THRESH * 0.8:
            handle_double_click(pts)
            return True

    elif action_type == "scroll_up":
        # Index + middle up, hand moving up
        if fingers[1] and fingers[2] and not fingers[3] and not fingers[4]:
            handle_scroll(pts, "up")
            return True

    elif action_type == "scroll_down":
        # Index + middle up, hand moving down
        if fingers[1] and fingers[2] and not fingers[3] and not fingers[4]:
            handle_scroll(pts, "down")
            return True

    elif action_type == "drag":
        # All fingers closed (fist)
        if n_up == 0:
            handle_drag(pts)
            return True
        else:
            release_drag()

    elif action_type == "volume_up":
        # Thumb up, index up, others down — hand raised
        if fingers[0] and fingers[1] and not fingers[2] and not fingers[3]:
            handle_volume(pts, "up")
            return True

    elif action_type == "volume_down":
        # Same pose but interpreted as down
        if fingers[0] and fingers[1] and not fingers[2] and not fingers[3]:
            handle_volume(pts, "down")
            return True

    elif action_type == "mute":
        # All five fingers spread (open palm then fist quickly handled by LaunchGate)
        handle_mute(pts)
        return True

    elif action_type == "media_play_pause":
        # Thumb + pinky up (shaka / hang loose)
        if fingers[0] and not fingers[1] and not fingers[2] and not fingers[3] and fingers[4]:
            handle_media(pts, "media_play_pause")
            return True

    elif action_type == "media_next":
        # Only index up, pointing right
        if fingers[1] and not fingers[2] and not fingers[3] and not fingers[4]:
            handle_media(pts, "media_next")
            return True

    elif action_type == "media_prev":
        # Only index up (same shape — direction intent handled by hold/cooldown)
        if fingers[1] and not fingers[2] and not fingers[3] and not fingers[4]:
            handle_media(pts, "media_prev")
            return True

    elif action_type == "screenshot":
        # Peace sign — index + middle up
        if fingers[1] and fingers[2] and not fingers[3] and not fingers[4] and not fingers[0]:
            handle_screenshot(pts)
            return True

    elif action_type == "zoom_in":
        d = _dist(pts[THUMB_TIP], pts[INDEX_TIP])
        if d > 0.15:   # fingers spread apart
            handle_zoom(pts, "in")
            return True

    elif action_type == "zoom_out":
        d = _dist(pts[THUMB_TIP], pts[INDEX_TIP])
        if d < PINCH_THRESH:
            handle_zoom(pts, "out")
            return True

    return False


def reset():
    """Call when session stops to release any held mouse buttons."""
    _state.reset()


# ── Available actions (exported for UI) ──────────────────────────────────────

CONTROL_ACTIONS = [
    "cursor_move",
    "left_click",
    "right_click",
    "double_click",
    "scroll_up",
    "scroll_down",
    "drag",
    "volume_up",
    "volume_down",
    "mute",
    "media_play_pause",
    "media_next",
    "media_prev",
    "screenshot",
    "zoom_in",
    "zoom_out",
]

CONTROL_ACTION_LABELS = {
    "cursor_move":      "Move cursor (open palm)",
    "left_click":       "Left click (thumb+index pinch)",
    "right_click":      "Right click (thumb+middle pinch)",
    "double_click":     "Double click (tight pinch)",
    "scroll_up":        "Scroll up (two fingers)",
    "scroll_down":      "Scroll down (two fingers)",
    "drag":             "Drag (closed fist)",
    "volume_up":        "Volume up (thumb+index up)",
    "volume_down":      "Volume down (thumb+index up)",
    "mute":             "Mute / unmute",
    "media_play_pause": "Play / pause (shaka)",
    "media_next":       "Next track (index right)",
    "media_prev":       "Previous track (index left)",
    "screenshot":       "Screenshot (peace sign)",
    "zoom_in":          "Zoom in (pinch open)",
    "zoom_out":         "Zoom out (pinch close)",
}
